load File.join(RADIANT_ROOT, "config", "routes.rb") 
